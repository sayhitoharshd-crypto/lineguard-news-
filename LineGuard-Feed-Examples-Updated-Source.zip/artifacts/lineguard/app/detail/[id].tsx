import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import * as WebBrowser from "expo-web-browser";
import { confirmSecureCase, disputeSecureCase, createSecurePaymentOrder, submitCaseApology, reviewCaseApology, setPublicListingConsent } from "@/lib/cases-api";

function timeAgo(timestamp: string): string {
  const diff = Date.now() - new Date(timestamp).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

function formatDate(iso: string) {
  return new Date(iso).toLocaleString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function DetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { getReportById, markGuilty, dismissReport, authUser: user, refreshCases } = useApp();

  const [payModalVisible, setPayModalVisible] = useState(false);
  const [amount, setAmount] = useState("");
  const [apology, setApology] = useState("");
  const [payerName, setPayerName] = useState("");
  const [paying, setPaying] = useState(false);
  const [activeImage, setActiveImage] = useState(0);
  const [agreedAmount, setAgreedAmount] = useState("");
  const [disputeReason, setDisputeReason] = useState("");
  const [caseBusy, setCaseBusy] = useState(false);
  const [publicApologyDraft, setPublicApologyDraft] = useState("");
  const [publicConsentBusy, setPublicConsentBusy] = useState(false);

  const report = getReportById(id ?? "");
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  if (!report) {
    return (
      <View style={[styles.notFound, { backgroundColor: colors.background }]}>
        <Feather name="alert-circle" size={48} color={colors.mutedForeground} />
        <Text style={[styles.notFoundText, { color: colors.foreground }]}>Report not found</Text>
        <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, { backgroundColor: colors.primary }]}>
          <Text style={styles.backBtnText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const isOwner = report.reporterId === user.id;
  const isParticipant = isOwner || report.accusedId === user.id;

  const handleShare = async () => {
    try {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      await Share.share({
        title: "LineGuard — Queue Justice Report",
        message: `🚨 Line Cutter Reported!\n\n📍 ${report.location.address}\n\n"${report.description}"\n\nReported via LineGuard — Queue Justice App`,
      });
    } catch {
      // User dismissed share sheet
    }
  };

  const handlePay = async () => {
    try {
      setPaying(true);
      const order = await createSecurePaymentOrder(report.id);
      if (!order.checkoutUrl) throw new Error("Secure checkout URL is not configured on the server.");
      await WebBrowser.openBrowserAsync(order.checkoutUrl);
      await refreshCases();
      Alert.alert("Payment submitted", "Return to this case shortly. LineGuard will mark it paid only after Razorpay's signed server confirmation.");
    } catch (error: any) {
      Alert.alert("Payment unavailable", error?.message || "Please try again later.");
    } finally { setPaying(false); }
  };

  const handleConfirmTerms = async () => {
    const value = Number(agreedAmount);
    if (!Number.isFinite(value) || value <= 0 || value > 200) { Alert.alert("Invalid compensation", "Enter a total amount between ₹1 and ₹200. The reporter receives 50%, capped at ₹100."); return; }
    try { setCaseBusy(true); await confirmSecureCase(report.id, value); await refreshCases(); Alert.alert("Confirmation saved", "Your confirmation is recorded. Both participants must confirm the same amount before payment can begin."); }
    catch (error: any) { Alert.alert("Could not confirm", error?.message || "Please try again."); }
    finally { setCaseBusy(false); }
  };

  const handleSubmitApology = async () => {
    if (publicApologyDraft.trim().length < 10) {
      Alert.alert("Apology too short", "Please write at least 10 characters.");
      return;
    }
    try {
      setCaseBusy(true);
      await submitCaseApology(report.id, publicApologyDraft.trim());
      await refreshCases();
      setPublicApologyDraft("");
      Alert.alert("Apology submitted", "The reporter can now review your apology. It will appear publicly only after approval.");
    } catch (error: any) {
      Alert.alert("Could not submit apology", error?.message || "Please try again.");
    } finally { setCaseBusy(false); }
  };

  const handleReviewApology = async (decision: "approve" | "request_changes") => {
    try {
      setCaseBusy(true);
      await reviewCaseApology(report.id, decision);
      await refreshCases();
      Alert.alert(decision === "approve" ? "Apology approved" : "Changes requested",
        decision === "approve" ? "The apology is now approved for public display." : "The accused participant can revise and resubmit the apology.");
    } catch (error: any) {
      Alert.alert("Could not review apology", error?.message || "Please try again.");
    } finally { setCaseBusy(false); }
  };

  const handlePublicConsent = async (enabled: boolean) => {
    try {
      setPublicConsentBusy(true);
      await setPublicListingConsent(report.id, enabled);
      await refreshCases();
      Alert.alert(enabled ? "Public listing consent saved" : "Public listing consent withdrawn", enabled ? "The public Shameboard listing will appear only after both participants consent and the apology is approved." : "This case will be removed from the public Shameboard.");
    } catch (error: any) {
      Alert.alert("Could not update public consent", error?.message || "Please try again.");
    } finally { setPublicConsentBusy(false); }
  };

  const handleDispute = async () => {
    if (disputeReason.trim().length < 10) { Alert.alert("Add a reason", "Please explain the dispute in at least 10 characters."); return; }
    try { setCaseBusy(true); await disputeSecureCase(report.id, disputeReason.trim()); await refreshCases(); Alert.alert("Dispute recorded", "The dispute has been securely recorded."); setDisputeReason(""); }
    catch (error: any) { Alert.alert("Could not submit dispute", error?.message || "Please try again."); }
    finally { setCaseBusy(false); }
  };

  const statusConfig = {
    pending: { label: "PENDING", color: colors.warning, bg: colors.warning + "22" },
    guilty: { label: "RESOLVED — PAYMENT UNVERIFIED", color: colors.success, bg: colors.success + "22" },
    dismissed: { label: "DISMISSED", color: colors.mutedForeground, bg: colors.muted },
  }[report.status];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient
        colors={[colors.gradientStart, colors.gradientMid]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.header, { paddingTop: topPad + 12 }]}
      >
        <TouchableOpacity onPress={() => router.back()} style={styles.headerBtn}>
          <Feather name="arrow-left" size={22} color="rgba(255,255,255,0.9)" />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: "#FFF" }]}>Incident Report</Text>
        <TouchableOpacity onPress={handleShare} style={styles.headerBtn}>
          <Feather name="share-2" size={20} color="rgba(255,255,255,0.9)" />
        </TouchableOpacity>
      </LinearGradient>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={[styles.content, { paddingBottom: 100 + bottomPad }]}
        showsVerticalScrollIndicator={false}
      >
        {report.mediaUris.length > 0 && (
          <View style={styles.imageContainer}>
            {report.mediaTypes?.[activeImage] === "video" ? (
              <TouchableOpacity onPress={() => WebBrowser.openBrowserAsync(report.mediaUris[activeImage])} style={[styles.mainImage, { backgroundColor: colors.muted, alignItems: "center", justifyContent: "center" }]}>
                <Feather name="play-circle" size={54} color={colors.primary} />
                <Text style={{ color: colors.foreground, marginTop: 8 }}>Play video evidence</Text>
              </TouchableOpacity>
            ) : (
              <Image source={{ uri: report.mediaUris[activeImage] }} style={styles.mainImage} resizeMode="cover" />
            )}
            {report.mediaUris.length > 1 && (
              <View style={styles.thumbnails}>
                {report.mediaUris.map((uri, i) => (
                  <TouchableOpacity key={i} onPress={() => setActiveImage(i)}>
                    {report.mediaTypes?.[i] === "video" ? (
                      <View style={[styles.thumb, { backgroundColor: colors.muted, alignItems: "center", justifyContent: "center", borderWidth: 2, borderColor: i === activeImage ? colors.primary : "transparent" }]}><Feather name="play" size={18} color={colors.primary} /></View>
                    ) : (
                      <Image source={{ uri }} style={[styles.thumb, { borderColor: i === activeImage ? colors.primary : "transparent" }]} />
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>
        )}

        {report.mediaUris.length === 0 && (
          <View style={[styles.noImageBanner, { backgroundColor: colors.primary + "15" }]}>
            <Feather name="camera-off" size={32} color={colors.primary} />
            <Text style={[styles.noImageText, { color: colors.mutedForeground }]}>No photo/video evidence</Text>
          </View>
        )}

        <View style={styles.body}>
          <View style={[styles.statusBadge, { backgroundColor: statusConfig.bg }]}>
            <View style={[styles.statusDot, { backgroundColor: statusConfig.color }]} />
            <Text style={[styles.statusText, { color: statusConfig.color }]}>{statusConfig.label}</Text>
          </View>

          {report.accusedName ? <Text style={{ color: colors.primary, fontSize: 13, fontWeight: "800", marginBottom: 8 }}>Public subject: {report.accusedName}</Text> : null}
          <Text style={[styles.description, { color: colors.foreground }]}>{report.description}</Text>

          {isParticipant && report.status === "pending" && (
            <View style={{ marginTop: 18, padding: 16, borderRadius: 16, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, gap: 10 }}>
              <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "700" }}>Participant actions</Text>
              <Text style={{ color: colors.mutedForeground, fontSize: 13 }}>Confirm the same compensation amount with the other participant, or record a dispute.</Text>
              <Text style={{ color: colors.foreground, fontSize: 13 }}>Reporter: {report.reporterConfirmed ? "Confirmed" : "Waiting"} · Other participant: {report.accusedConfirmed ? "Confirmed" : "Waiting"}</Text>
              {report.agreedCompensation !== null && report.agreedCompensation !== undefined ? <Text style={{ color: colors.primary, fontWeight: "700" }}>Agreed amount: ₹{report.agreedCompensation}</Text> : null}
              <TextInput value={agreedAmount} onChangeText={setAgreedAmount} keyboardType="decimal-pad" placeholder="Total compensation (₹1–₹200)" placeholderTextColor={colors.mutedForeground} style={{ color: colors.foreground, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12 }} />
              <TouchableOpacity disabled={caseBusy} onPress={handleConfirmTerms} style={{ backgroundColor: colors.primary, borderRadius: 10, padding: 13, alignItems: "center", opacity: caseBusy ? 0.6 : 1 }}><Text style={{ color: "#fff", fontWeight: "700" }}>{caseBusy ? "Please wait…" : "Confirm compensation"}</Text></TouchableOpacity>
              <TextInput value={disputeReason} onChangeText={setDisputeReason} multiline placeholder="If you dispute this case, explain why" placeholderTextColor={colors.mutedForeground} style={{ minHeight: 72, color: colors.foreground, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12, textAlignVertical: "top" }} />
              <TouchableOpacity disabled={caseBusy} onPress={handleDispute} style={{ borderWidth: 1, borderColor: colors.warning, borderRadius: 10, padding: 12, alignItems: "center" }}><Text style={{ color: colors.warning, fontWeight: "700" }}>Submit dispute</Text></TouchableOpacity>
            </View>
          )}
          {report.accusedId === user.id && report.status === "pending" && (
            <View style={{ marginTop: 12 }}><Text style={{ color: colors.mutedForeground, fontSize: 12 }}>Payment becomes available only after both participants confirm matching compensation.</Text></View>
          )}

          {report.apologyStatus === "approved" && report.apologyText ? (
            <View style={{ marginTop: 16, padding: 16, borderRadius: 16, backgroundColor: colors.success + "12", borderWidth: 1, borderColor: colors.success + "45", gap: 8 }}>
              <Text style={{ color: colors.success, fontSize: 15, fontWeight: "800" }}>PUBLIC APOLOGY · APPROVED</Text>
              <Text style={{ color: colors.foreground, fontSize: 14, lineHeight: 21 }}>{report.apologyText}</Text>
            </View>
          ) : null}

          {isParticipant && report.apologyStatus === "pending_review" ? (
            <View style={{ marginTop: 16, padding: 16, borderRadius: 16, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, gap: 10 }}>
              <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "800" }}>Public apology awaiting review</Text>
              <Text style={{ color: colors.foreground, fontSize: 14, lineHeight: 21 }}>{report.apologyText}</Text>
              {isOwner ? (
                <>
                  <Text style={{ color: colors.mutedForeground, fontSize: 12 }}>Approve to publish this apology on the case page, or request changes.</Text>
                  <TouchableOpacity disabled={caseBusy} onPress={() => handleReviewApology("approve")} style={{ backgroundColor: colors.success, borderRadius: 10, padding: 13, alignItems: "center" }}>
                    <Text style={{ color: "#fff", fontWeight: "800" }}>Approve public apology</Text>
                  </TouchableOpacity>
                  <TouchableOpacity disabled={caseBusy} onPress={() => handleReviewApology("request_changes")} style={{ borderWidth: 1, borderColor: colors.warning, borderRadius: 10, padding: 12, alignItems: "center" }}>
                    <Text style={{ color: colors.warning, fontWeight: "800" }}>Request changes</Text>
                  </TouchableOpacity>
                </>
              ) : <Text style={{ color: colors.warning, fontSize: 12 }}>Waiting for the reporter to review this apology.</Text>}
            </View>
          ) : null}

          {report.accusedId === user.id && report.caseStatus === "agreed" && report.apologyStatus !== "approved" && report.apologyStatus !== "pending_review" ? (
            <View style={{ marginTop: 16, padding: 16, borderRadius: 16, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, gap: 10 }}>
              <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "800" }}>Submit public apology</Text>
              <Text style={{ color: colors.mutedForeground, fontSize: 12 }}>Write an apology for the reporter to review. It will not be shown publicly unless the reporter approves it.</Text>
              <TextInput value={publicApologyDraft} onChangeText={setPublicApologyDraft} multiline maxLength={1500} placeholder="Write your public apology..." placeholderTextColor={colors.mutedForeground} style={{ minHeight: 110, color: colors.foreground, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12, textAlignVertical: "top" }} />
              <TouchableOpacity disabled={caseBusy} onPress={handleSubmitApology} style={{ backgroundColor: colors.primary, borderRadius: 10, padding: 13, alignItems: "center", opacity: caseBusy ? 0.6 : 1 }}>
                <Text style={{ color: "#fff", fontWeight: "800" }}>{caseBusy ? "Please wait…" : report.apologyStatus === "changes_requested" ? "Resubmit apology" : "Send apology for review"}</Text>
              </TouchableOpacity>
            </View>
          ) : null}

          {isParticipant && report.caseStatus === "agreed" && report.apologyStatus === "approved" ? (
            <View style={{ marginTop: 16, padding: 16, borderRadius: 16, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, gap: 10 }}>
              <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "800" }}>Public Shameboard permission</Text>
              <Text style={{ color: colors.mutedForeground, fontSize: 12, lineHeight: 18 }}>The public listing can show both participants’ names, the incident description, the approved apology and attached images/videos. Anyone may copy or share public material. Exact contact details and email addresses are never shown. Both participants must opt in; either can withdraw consent later.</Text>
              <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "700" }}>Your consent: {((isOwner && report.reporterPublicConsent) || (!isOwner && report.accusedPublicConsent)) ? "Granted" : "Not granted"}</Text>
              <TouchableOpacity disabled={publicConsentBusy} onPress={() => handlePublicConsent(!((isOwner && report.reporterPublicConsent) || (!isOwner && report.accusedPublicConsent)))} style={{ backgroundColor: ((isOwner && report.reporterPublicConsent) || (!isOwner && report.accusedPublicConsent)) ? colors.card : colors.primary, borderWidth: 1, borderColor: colors.primary, borderRadius: 10, padding: 13, alignItems: "center", opacity: publicConsentBusy ? 0.6 : 1 }}>
                <Text style={{ color: ((isOwner && report.reporterPublicConsent) || (!isOwner && report.accusedPublicConsent)) ? colors.primary : "#fff", fontWeight: "800" }}>{publicConsentBusy ? "Please wait…" : ((isOwner && report.reporterPublicConsent) || (!isOwner && report.accusedPublicConsent)) ? "Withdraw public consent" : "I consent to public listing"}</Text>
              </TouchableOpacity>
              <Text style={{ color: colors.mutedForeground, fontSize: 11 }}>Reporter: {report.reporterPublicConsent ? "Consented" : "Not yet"} · Accused: {report.accusedPublicConsent ? "Consented" : "Not yet"}</Text>
            </View>
          ) : null}

          <View style={styles.metaRow}>
            <View style={styles.metaItem}>
              <Feather name="map-pin" size={14} color={colors.primary} />
              <Text style={[styles.metaText, { color: colors.mutedForeground }]}>{report.location.address}</Text>
            </View>
            <View style={styles.metaItem}>
              <Feather name="clock" size={14} color={colors.secondary} />
              <Text style={[styles.metaText, { color: colors.mutedForeground }]}>{formatDate(report.timestamp)}</Text>
            </View>
          </View>

          <View style={[styles.divider, { backgroundColor: colors.border }]} />

          <View style={styles.reporterSection}>
            <View style={[styles.reporterAvatar, { backgroundColor: report.reporterColor }]}>
              <Text style={styles.avatarText}>
                {report.reporterName.split(" ").map((n: string) => n[0]).join("").substring(0, 2).toUpperCase()}
              </Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.reporterLabel, { color: colors.mutedForeground }]}>Reported by</Text>
              <Text style={[styles.reporterName, { color: colors.foreground }]}>
                {isOwner ? "You" : report.reporterName}
              </Text>
            </View>
            <Text style={[styles.timeAgo, { color: colors.mutedForeground }]}>{timeAgo(report.timestamp)}</Text>
          </View>

          {report.status === "guilty" && report.payment && (
            <View style={[styles.paymentCard, { backgroundColor: colors.success + "12", borderColor: colors.success + "30" }]}>
              <View style={styles.paymentHeader}>
                <View style={[styles.payIconCircle, { backgroundColor: colors.success }]}>
                  <Feather name="check" size={16} color="#FFF" />
                </View>
                <Text style={[styles.paymentTitle, { color: colors.success }]}>Resolution claimed · unverified</Text>
              </View>
              <View style={styles.paymentDetail}>
                <Text style={[styles.payerName, { color: colors.foreground }]}>{report.payment.payerName}</Text>
                <Text style={[styles.payAmount, { color: colors.success }]}>₹{report.payment.amount}</Text>
              </View>
              <View style={[styles.apologyBox, { backgroundColor: colors.success + "08" }]}>
                <Feather name="message-square" size={13} color={colors.success} />
                <Text style={[styles.apologyText, { color: colors.foreground }]}>{report.payment.apology}</Text>
              </View>
              <Text style={[styles.paidDate, { color: colors.mutedForeground }]}>
                {formatDate(report.payment.paidAt)}
              </Text>
            </View>
          )}

          {report.status === "pending" && report.accusedId === user.id && (
            <View style={[styles.guiltyCTA, { backgroundColor: colors.primary + "10", borderColor: colors.primary + "25" }]}>
              <Feather name="alert-triangle" size={18} color={colors.primary} />
              <View style={{ flex: 1 }}>
                <Text style={[styles.ctaTitle, { color: colors.foreground }]}>Are you involved in this report?</Text>
                <Text style={[styles.ctaDesc, { color: colors.mutedForeground }]}>
                  Pay the reporter and issue a public apology to resolve this case.
                </Text>
              </View>
            </View>
          )}
        </View>
      </ScrollView>

      {report.status === "pending" && report.accusedId === user.id && report.caseStatus === "agreed" && (
        <View style={[styles.footerBar, { backgroundColor: colors.card, borderTopColor: colors.border, paddingBottom: bottomPad + 12 }]}>
          <TouchableOpacity
            onPress={handlePay}
            style={[styles.payBtn, { backgroundColor: colors.primary }]}
          >
            <Feather name="dollar-sign" size={18} color="#FFF" />
            <Text style={styles.payBtnText}>{paying ? "Opening checkout…" : "Pay agreed compensation"}</Text>
          </TouchableOpacity>
        </View>
      )}

      <Modal visible={payModalVisible} transparent animationType="slide">
        <Pressable style={styles.modalOverlay} onPress={() => !paying && setPayModalVisible(false)}>
          <Pressable
            style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={e => e.stopPropagation()}
          >
            <View style={styles.modalHandle} />
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>Propose a Resolution</Text>
            <Text style={[styles.modalSubtitle, { color: colors.mutedForeground }]}>
              Any resolution must be voluntary. The total compensation is split 50/50: the reporter receives half (maximum ₹100) and LineGuard receives half. Provider processing fees are separate.
            </Text>

            <View style={styles.modalFields}>
              <TextInput
                style={[styles.modalInput, { backgroundColor: colors.muted, color: colors.foreground, borderColor: colors.border }]}
                placeholder="Your name"
                placeholderTextColor={colors.mutedForeground}
                value={payerName}
                onChangeText={setPayerName}
              />
              <View style={[styles.amountInput, { backgroundColor: colors.muted, borderColor: colors.border }]}>
                <Text style={[styles.rupee, { color: colors.foreground }]}>₹</Text>
                <TextInput
                  style={[styles.amountField, { color: colors.foreground }]}
                  placeholder="Total amount (maximum ₹200)"
                  placeholderTextColor={colors.mutedForeground}
                  value={amount}
                  onChangeText={setAmount}
                  keyboardType="numeric"
                />
              </View>
              <TextInput
                style={[styles.apologyInput, { backgroundColor: colors.muted, color: colors.foreground, borderColor: colors.border }]}
                placeholder="Write your public apology..."
                placeholderTextColor={colors.mutedForeground}
                value={apology}
                onChangeText={setApology}
                multiline
                textAlignVertical="top"
              />
            </View>

            <View style={styles.modalButtons}>
              <TouchableOpacity
                onPress={() => setPayModalVisible(false)}
                disabled={paying}
                style={[styles.cancelBtn, { backgroundColor: colors.muted }]}
              >
                <Text style={[styles.cancelText, { color: colors.mutedForeground }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handlePay}
                disabled={paying}
                style={[styles.confirmPayBtn, { backgroundColor: colors.primary }]}
              >
                {paying ? (
                  <ActivityIndicator color="#FFF" />
                ) : (
                  <Text style={styles.confirmPayText}>Submit Resolution</Text>
                )}
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  notFound: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 16,
  },
  notFoundText: {
    fontSize: 18,
    fontFamily: "Inter_600SemiBold",
  },
  backBtn: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  backBtnText: {
    color: "#FFF",
    fontFamily: "Inter_700Bold",
    fontSize: 15,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 8,
    paddingBottom: 12,
    borderBottomWidth: 1,
  },
  headerBtn: {
    width: 44,
    height: 44,
    alignItems: "center",
    justifyContent: "center",
  },
  headerTitle: {
    fontSize: 17,
    fontFamily: "Inter_700Bold",
  },
  content: { gap: 0 },
  imageContainer: { width: "100%" },
  mainImage: {
    width: "100%",
    height: 260,
  },
  thumbnails: {
    flexDirection: "row",
    padding: 8,
    gap: 6,
  },
  thumb: {
    width: 56,
    height: 56,
    borderRadius: 8,
    borderWidth: 2,
  },
  noImageBanner: {
    height: 100,
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  noImageText: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
  },
  body: {
    padding: 16,
    gap: 14,
  },
  statusBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    alignSelf: "flex-start",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusText: {
    fontSize: 12,
    fontFamily: "Inter_700Bold",
    letterSpacing: 0.5,
  },
  description: {
    fontSize: 16,
    fontFamily: "Inter_400Regular",
    lineHeight: 24,
  },
  metaRow: {
    gap: 8,
  },
  metaItem: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
  },
  metaText: {
    flex: 1,
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    lineHeight: 18,
  },
  divider: {
    height: 1,
  },
  reporterSection: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  reporterAvatar: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: {
    color: "#FFF",
    fontSize: 14,
    fontFamily: "Inter_700Bold",
  },
  reporterLabel: {
    fontSize: 11,
    fontFamily: "Inter_400Regular",
  },
  reporterName: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
  },
  timeAgo: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
  },
  paymentCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    gap: 10,
  },
  paymentHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  payIconCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  paymentTitle: {
    fontSize: 15,
    fontFamily: "Inter_700Bold",
  },
  paymentDetail: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  payerName: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
  },
  payAmount: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
  },
  apologyBox: {
    flexDirection: "row",
    gap: 8,
    padding: 12,
    borderRadius: 10,
    alignItems: "flex-start",
  },
  apologyText: {
    flex: 1,
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    fontStyle: "italic",
    lineHeight: 20,
  },
  paidDate: {
    fontSize: 11,
    fontFamily: "Inter_400Regular",
  },
  guiltyCTA: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    flexDirection: "row",
    gap: 12,
    alignItems: "flex-start",
  },
  ctaTitle: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
  },
  ctaDesc: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
    lineHeight: 18,
  },
  footerBar: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 16,
    paddingTop: 12,
    borderTopWidth: 1,
  },
  payBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    padding: 16,
    borderRadius: 14,
  },
  payBtnText: {
    color: "#FFF",
    fontSize: 16,
    fontFamily: "Inter_700Bold",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.6)",
    justifyContent: "flex-end",
  },
  modalCard: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderWidth: 1,
    padding: 24,
    gap: 14,
  },
  modalHandle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    backgroundColor: "#E5E5E5",
    alignSelf: "center",
    marginBottom: 4,
  },
  modalTitle: {
    fontSize: 18,
    fontFamily: "Inter_700Bold",
  },
  modalSubtitle: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    lineHeight: 18,
    marginTop: -6,
  },
  modalFields: {
    gap: 10,
  },
  modalInput: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  amountInput: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 14,
    gap: 4,
  },
  rupee: {
    fontSize: 20,
    fontFamily: "Inter_700Bold",
  },
  amountField: {
    flex: 1,
    fontSize: 20,
    fontFamily: "Inter_700Bold",
    paddingVertical: 12,
  },
  apologyInput: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    minHeight: 90,
    lineHeight: 20,
  },
  modalButtons: {
    flexDirection: "row",
    gap: 10,
  },
  cancelBtn: {
    flex: 1,
    padding: 14,
    borderRadius: 12,
    alignItems: "center",
  },
  cancelText: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
  },
  confirmPayBtn: {
    flex: 2,
    padding: 14,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  confirmPayText: {
    color: "#FFF",
    fontSize: 15,
    fontFamily: "Inter_700Bold",
  },
});
